<?php

return [
    'place' => 'ĐỊA ĐIỂM DU LỊCH',
    'about' => 'Giới thiệu',
    'livi' => 'về Livitrans',
    'about_content_1' => 'Với bề dầy hoạt động 10 năm, Livitrans luôn là sự tin cậy của mọi khách hàng và đối tác. Bởi lẽ, dịch vụ không ngừng hoàn thiện để hài lòng khách hàng là con đường thành công của chúng tôi.',
    'about_content_2' => 'Sau thời gian nâng cấp dịch vụ, hoàn chỉnh các quy trình phục vụ và đầu tư mới cơ sở vật chất, chúng tôi tự tin trở lại với quý khách hàng yêu quý với một diện mạo mới.',
    'about_content_3' => 'Và chính thức từ tháng 10 năm 2017, chúng tôi sẵn sàng đưa vào hoạt động đoàn tàu Du lịch chất lượng 4 sao với chất lượng vượt trội dành cho quý khách.

    Ban điều hành Công ty chúng tôi xin trân trọng gửi tới quý khách hàng và đối tác lời chúc tốt đẹp nhất thông qua chất lượng dịch vụ của mình.',
    'about_title_2' => 'PHƯƠNG TRÂM',
    'about_title_3' => 'MONG MUỐN',
    'service' => 'DỊCH VỤ',
    'service_title_1' => 'VẬN CHUYỂN',
    'service_title_2' => 'KÝ GỬI',
    'service_title_3' => 'BỐC XẾP HÀNG HÓA',
    'service_content_1' => 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut',
    'service_content_2' => 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut',
    'service_content_3' => 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut',
    'news' => 'Tin mới',
    'read_more' => 'Xem thêm'
];
