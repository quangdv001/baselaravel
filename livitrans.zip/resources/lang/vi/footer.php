<?php

return [
    'livi_name' => 'CÔNG TY CP VẬN TẢI VÀ THƯƠNG MẠI LIVITRANS ( LIVITRANS JSC,..).',
    'footer_1' => 'Phòng tiễn khách: Khách sạn Cây Xoài 118 Lê Duẩn - Hoàn Kiếm - Hà Nội',
    'footer_2' => 'Địa chỉ Phòng vé: Số 1 Trần Quý Cáp - Phường Văn Miếu - Quận Đống Đa - Hà nội',
    'footer_3' => 'Hotline: 0243.9429918',
    'footer_4' => 'Điện thoại phòng vé: 0904.101.488',
    'footer_5' => 'Email: booking@livitrans.com',
    'contact' => 'Liên hệ',
    'contact_1' => 'FAQs - Hỏi đáp',
    'contact_2' => 'Chính sách vận chuyển',
    'contact_3' => 'Hướng dẫn thanh toán',
    'contact_4' => 'Quy định',
    'contact_5' => 'CSKH',
    'sitemap' => 'SITEMAP',
    'sitemap_1' => 'Đặt vé',
    'sitemap_2' => 'Du lịch',
    'sitemap_3' => 'Hủy chuyến',
    'sitemap_4' => 'Gửi hành lý',
    'sitemap_5' => 'Ký gửi',
];
