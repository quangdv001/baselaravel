<?php

return [
    'livi_name' => 'CÔNG TY CP VẬN TẢI VÀ THƯƠNG MẠI LIVITRANS ( LIVITRANS JSC,..).',
    'footer_1' => 'Phòng tiễn khách: ',
    'footer_2' => 'Địa chỉ Phòng vé: ',
    'footer_3' => 'Hotline: ',
    'footer_4' => 'Điện thoại phòng vé: ',
    'footer_5' => 'Email: ',
    'contact' => 'Liên hệ',
    'contact_1' => 'FAQs - Hỏi đáp',
    'contact_2' => 'Chính sách vận chuyển',
    'contact_3' => 'Hướng dẫn thanh toán',
    'contact_4' => 'Quy định',
    'contact_5' => 'CSKH',
    'sitemap' => 'SITEMAP',
    'sitemap_1' => 'Về chúng tôi',
    'sitemap_2' => 'Đặt vé',
    'sitemap_3' => 'Khuyến mãi',
    'sitemap_4' => 'Tin tức',
];
