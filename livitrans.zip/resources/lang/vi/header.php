<?php

return [
    'lang_vi' => 'Tiếng việt',
    'lang_en' => 'Tiếng Anh',
    'contact' => 'Liên hệ',
    'home' => 'Trang chủ',
    'about' => 'Giới thiệu',
    'booking' => 'Đặt vé',
    'regulations' => 'Quy định',
    'sale' => 'Khuyến mãi',
    'article' => 'Tin tức',
    'about_us' => 'Về chúng tôi',
    'gastation' => 'Đại lý vé tàu',
    'ticket_location' => 'Điểm bán vé',
    'album_image' => 'Album ảnh'
];
