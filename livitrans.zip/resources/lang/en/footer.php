<?php

return [
    'livi_name' => 'LIVITRANS JSC',
    'footer_1' => 'Guest room: ',
    'footer_2' => 'Ticket office address: ',
    'footer_3' => 'Hotline: ',
    'footer_4' => 'Telephone ticket office: ',
    'footer_5' => 'Email: ',
    'contact' => 'Contact',
    'contact_1' => 'FAQs',
    'contact_2' => 'Shipping policy',
    'contact_3' => 'Payment Guide',
    'contact_4' => 'Regulations',
    'contact_5' => 'Customer Care',
    'sitemap' => 'SITEMAP',
    'sitemap_1' => 'About Us',
    'sitemap_2' => 'Booking Tickets',
    'sitemap_3' => 'Sales',
    'sitemap_4' => 'Article'
];
