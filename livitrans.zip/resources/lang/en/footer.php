<?php

return [
    'livi_name' => 'LIVITRANS JSC',
    'footer_1' => 'Guest room: Hotel Cây Xoài 118 Lê Duẩn - Hoàn Kiếm - Hà Nội',
    'footer_2' => 'Ticket office address: 1 Trần Quý Cáp - Phường Văn Miếu - Quận Đống Đa - Hà nội',
    'footer_3' => 'Hotline: 0243.9429918',
    'footer_4' => 'Telephone ticket office: 0904.101.488',
    'footer_5' => 'Email: booking@livitrans.com',
    'contact' => 'Contact',
    'contact_1' => 'FAQs',
    'contact_2' => 'Shipping policy',
    'contact_3' => 'Payment Guide',
    'contact_4' => 'Regulations',
    'contact_5' => 'customer care',
    'sitemap' => 'SITEMAP',
    'sitemap_1' => 'Booking tickets',
    'sitemap_2' => 'Travel',
    'sitemap_3' => 'Cancel the trip',
    'sitemap_4' => 'Send luggage',
    'sitemap_5' => 'Deposit',
];
