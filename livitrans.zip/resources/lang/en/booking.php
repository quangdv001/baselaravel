<?php

return [
    'book' => 'Booking',
    'booking' => 'Booking',
    'contact' => 'Contact us',
    'way1' => 'One Way',
    'way2' => 'Round Trip',
    'from' => 'From',
    'to' => 'To',
    'amount' => 'Amount of people',
    'start' => 'Start time',
    'end' => 'End time',
    'note' => 'Note',
    'note_info' => 'Booking info',
    'name' => 'Full name',
    'email' => 'Email',
    'phone' => 'Phone number',
    'address' => 'Address',
    'payment' => 'Payment method',
    'payment_1' => 'Credit Card',
    'payment_2' => 'Transfer',
    'payment_3' => 'Direct',
    'article' => 'New article'
];
