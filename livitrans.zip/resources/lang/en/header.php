<?php

return [
    'lang_vi' => 'Vietnamese',
    'lang_en' => 'English',
    'contact' => 'Contact',
    'home' => 'Home',
    'about' => 'About',
    'booking' => 'Booking',
    'regulations' => 'Regulations',
    'sale' => 'Sales',
    'article' => 'Article',
    'about_us' => 'About Us',
    'gastation' => 'Gastation',
    'ticket_location' => 'Ticket Location',
    'album_image' => 'Album Images'
];
