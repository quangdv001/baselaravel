<link rel="stylesheet" href="//cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
<!-- Icons-->
<link href="https://unpkg.com/@coreui/coreui/dist/css/coreui.min.css" rel="stylesheet" >
<link href="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.3.0/css/flag-icon.min.css" rel="stylesheet">
<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/simple-line-icons/2.4.1/css/simple-line-icons.css" rel="stylesheet">
<!-- Main styles for this application-->
<link href="{{ asset('public/assets/admin/themes/coreui/css/style.css') }}" rel="stylesheet">
<link href="{{ asset('public/assets/admin/themes/coreui/vendors/pace-progress/css/pace.min.css') }}" rel="stylesheet">

<link rel="stylesheet" href="{{ asset('public/assets/admin/plugins/buttonloader/buttonLoader.css') }}">
<link rel="stylesheet" href="{{ asset('public/assets/admin/plugins/preloader/preloader.css') }}">
<link rel="stylesheet" href="{{ asset('public/assets/admin/plugins/waitme/waitMe.min.css') }}">
<link rel="stylesheet" href="{{ asset('public/assets/admin/plugins/selectize/selectize.default.css') }}"> 
<link rel="stylesheet" href="{{ asset('public/assets/admin/plugins/nestable/custom.css') }}">
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-daterangepicker/3.0.5/daterangepicker.min.css" />
@yield('lib_css')
<link rel="stylesheet" href="{{ asset('public/assets/admin/css/custom.css') }}">
@yield('custom_css')