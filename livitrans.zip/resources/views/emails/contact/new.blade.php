<p>
Họ tên: {{ $info['name'] }} 
</p>
<p>
Số điện thoại: {{ $info['phone'] }} 
</p>
<p>
Email: {{ $info['email'] }} 
</p>
<p>
Nội dung: {{ $info['content'] }}
</p>