<div class="list-post-aside sticky-top" style="top: 60px;"><a href="#" style="display:block">
  <div class="row"><img src="https://file4.batdongsan.com.vn/2019/03/12/RUFz0fap/20190312163851-0eab.jpg" alt="" width="100%" height="369px"/></div></a>
  @include('site.components.latestNews')
  @include('site.components.latestProjects')
</div>
{{-- <h3 class="module-title"><a href="#">Dự án nổi bật</a></h3>
<div class="list-course">
  <div class="row">
    <div class="col">
      <div class="block gray-block">
        <div class="cover-image"><img src="./assets/images/services_02.png" alt=""/>
        </div>
        <div class="title">
          <h3><a href="project-detail.html">Dự án title 2</a></h3>
          <div class="meta-info"><a class="meta-info-item" href="#0">Dự án</a><span class="meta-info-item">22 Dự án</span></div>
        </div><a class="btn btn-raised btn-md btn-brand" href="#0"><i class="inc-icon inc-play"> </i><span>Xem chi tiết</span></a>
        <div class="block-info"><a class="meta-info-item" href="project.html">Dự án</a><span class="meta-info-item">22 Dự án</span></div>
      </div>
    </div>
    <div class="col">
      <div class="block gray-block">
        <div class="cover-image"><img src="./assets/images/services_03.png" alt=""/>
        </div>
        <div class="title">
          <h3><a href="project-detail.html">Dự án title 3</a></h3>
          <div class="meta-info"><a class="meta-info-item" href="#0">Dự án</a><span class="meta-info-item">22 Dự án</span></div>
        </div><a class="btn btn-raised btn-md btn-brand" href="#0"><i class="inc-icon inc-play"> </i><span>Xem chi tiết</span></a>
        <div class="block-info"><a class="meta-info-item" href="project.html">Dự án</a><span class="meta-info-item">22 Dự án</span></div>
      </div>
    </div>
    <div class="col">
      <div class="block gray-block">
        <div class="cover-image"><img src="./assets/images/services_02.png" alt=""/>
        </div>
        <div class="title">
          <h3><a href="project-detail.html">Dự án title 3</a></h3>
          <div class="meta-info"><a class="meta-info-item" href="#0">Dự án</a><span class="meta-info-item">22 Dự án</span></div>
        </div><a class="btn btn-raised btn-md btn-brand" href="#0"><i class="inc-icon inc-play"> </i><span>Xem chi tiết</span></a>
        <div class="block-info"><a class="meta-info-item" href="project.html">Dự án</a><span class="meta-info-item">22 Dự án</span></div>
      </div>
    </div>
  </div>
</div> --}}