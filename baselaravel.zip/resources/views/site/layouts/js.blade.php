<script src="{{ asset('assets/frontend/libs/jquery/jquery-3.2.1.min.js') }}"></script>
<script src="{{ asset('assets/frontend/libs/popper/umd/popper.js') }}"></script>
<script src="{{ asset('assets/frontend/libs/bootstrap-material/js/bootstrap-material-design.min.js') }}"></script>
<script src="{{ asset('assets/frontend/libs/owlcarousel2/owl.carousel.min.js') }}"></script>
<script src="{{ asset('assets/frontend/libs/slimScroll/jquery.slimscroll.min.js') }}" type="text/javascript"></script>
<script src="{{ asset('assets/frontend/js/main.js') }}"></script>