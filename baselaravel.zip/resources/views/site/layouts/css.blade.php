<link rel="stylesheet" href="{{ asset('assets/frontend/libs/font-roboto/style.css') }}">
<link rel="stylesheet" href="{{ asset('assets/frontend/libs/material-design-icons/css/material-icons.min.css') }}">
<link rel="stylesheet" href="{{ asset('assets/frontend/libs/fontawesome5/css/all.css') }}">
<link rel="stylesheet" href="{{ asset('assets/frontend/libs/bootstrap-material/css/bootstrap-material-design.min.css') }}" type="text/css">
<link rel="stylesheet" href="{{ asset('assets/frontend/libs/owlcarousel2/assets/owl.carousel.min.css') }}" type="text/css">
<link rel="stylesheet" href="{{ asset('assets/frontend/libs/owlcarousel2/assets/owl.theme.default.min.css') }}" type="text/css">
<link rel="stylesheet" href="{{ asset('assets/frontend/css/theme.css') }}" type="text/css">