<h3 class="module-title"><a href="#">Tin Liên quan</a></h3>
@for ($i = 0; $i < 5; $i++)
    <div class="news-post line-bottom list-style-post small-post">
        <div class="news-post-content">
        <div class="post-title title"><i class="list-icon fas fa-circle"></i><a class="news-post-link" href="/single.html">Lorem Ipsum là gì, Tại sao lại sử dụng nó?</a></div>
        </div>
    </div>
@endfor