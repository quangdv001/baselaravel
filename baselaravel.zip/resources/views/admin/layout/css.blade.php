<link rel="stylesheet" href="//cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="{{ asset('assets/admin/themes/vendors/iconfonts/mdi/css/materialdesignicons.min.css') }}">
<link rel="stylesheet" href="{{ asset('assets/admin/themes/vendors/css/vendor.bundle.base.css') }}">
<link rel="stylesheet" href="{{ asset('assets/admin/themes/vendors/css/vendor.bundle.addons.css') }}">
<link rel="stylesheet" href="{{ asset('assets/admin/themes/vendors/iconfonts/font-awesome/css/font-awesome.css') }}">
<link rel="stylesheet" href="{{ asset('assets/admin/plugins/buttonloader/buttonLoader.css') }}">
<link rel="stylesheet" href="{{ asset('assets/admin/plugins/preloader/preloader.css') }}">
<link rel="stylesheet" href="{{ asset('assets/admin/plugins/waitme/waitMe.min.css') }}">
<link rel="stylesheet" href="{{ asset('assets/admin/plugins/nestable/custom.css') }}">
<link rel="stylesheet" href="{{ asset('assets/admin/plugins/selectize/selectize.default.css') }}"> 
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-daterangepicker/3.0.5/daterangepicker.min.css" />
@yield('lib_css')
<link rel="stylesheet" href="{{ asset('assets/admin/themes/css/style.css') }}">
<link rel="stylesheet" href="{{ asset('assets/admin/css/custom.css') }}">


@yield('custom_css')